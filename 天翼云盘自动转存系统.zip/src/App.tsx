import React, { useState } from 'react';
import { 
  User, 
  Files, 
  ClipboardList, 
  PlayCircle, 
  LayoutGrid, 
  Rss, 
  Link2, 
  Settings, 
  Monitor,
  Github,
  Sun,
  Plus,
  Trash2,
  RefreshCw,
  MoreVertical,
  Search,
  Filter,
  ChevronRight,
  MessageSquare,
  FileText,
  Bell,
  Cpu,
  X,
  CheckCircle2,
  AlertCircle,
  Menu
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
type TabType = 'account' | 'fileManager' | 'task' | 'autoSeries' | 'organizer' | 'subscription' | 'strmConfig' | 'media' | 'settings';

// --- Components ---

const AccountTab = ({ onAddAccount }: { onAddAccount: () => void }) => (
  <div className="space-y-6">
    <div className="flex items-center justify-between">
      <div className="flex gap-3">
        <button 
          onClick={onAddAccount}
          className="bg-[#0b57d0] text-white px-6 py-2.5 rounded-full text-sm font-medium hover:bg-[#0b57d0]/90 transition-all shadow-sm flex items-center gap-2"
        >
          <Plus size={18} /> 添加账号
        </button>
        <button className="bg-[#f8dada] text-[#900b09] px-6 py-2.5 rounded-full text-sm font-medium hover:bg-[#f8dada]/80 transition-all flex items-center gap-2">
          <Trash2 size={18} /> 清空回收站
        </button>
      </div>
    </div>
    
    <div className="bg-white rounded-3xl border border-slate-200/60 overflow-hidden shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50/50 border-b border-slate-100">
            <tr>
              <th className="px-6 py-4 font-medium text-slate-500">操作</th>
              <th className="px-6 py-4 font-medium text-slate-500">用户名</th>
              <th className="px-6 py-4 font-medium text-slate-500">别名</th>
              <th className="px-6 py-4 font-medium text-slate-500">个人容量</th>
              <th className="px-6 py-4 font-medium text-slate-500">家庭容量</th>
              <th className="px-6 py-4 font-medium text-slate-500">媒体目录</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            <tr className="hover:bg-slate-50/50 transition-colors group">
              <td className="px-6 py-4">
                <button className="text-[#0b57d0] hover:text-[#0b57d0]/80 font-medium transition-colors">编辑</button>
              </td>
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#d3e3fd] text-[#041e49] flex items-center justify-center font-bold text-xs">
                    138
                  </div>
                  <span className="font-medium text-slate-900">138****8888</span>
                </div>
              </td>
              <td className="px-6 py-4">
                <span className="px-3 py-1 bg-[#d3e3fd] text-[#041e49] rounded-full text-xs font-medium">主账号</span>
              </td>
              <td className="px-6 py-4">
                <div className="flex flex-col gap-1.5">
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>2.4TB</span>
                    <span>10TB</span>
                  </div>
                  <div className="w-32 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-[#0b57d0] w-[24%]" />
                  </div>
                </div>
              </td>
              <td className="px-6 py-4">
                <div className="flex flex-col gap-1.5">
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>0B</span>
                    <span>2TB</span>
                  </div>
                  <div className="w-32 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-slate-300 w-[0%]" />
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 text-slate-400 italic">未设置</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

const TaskTab = ({ onCreateTask }: { onCreateTask: () => void }) => (
  <div className="space-y-6">
    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
      <div className="flex gap-3">
        <button 
          onClick={onCreateTask}
          className="bg-[#0b57d0] text-white px-6 py-2.5 rounded-full text-sm font-medium hover:bg-[#0b57d0]/90 transition-all shadow-sm flex items-center gap-2"
        >
          <Plus size={18} /> 创建任务
        </button>
        <button className="bg-white border border-slate-300 px-6 py-2.5 rounded-full text-sm font-medium hover:bg-slate-50 transition-all flex items-center gap-2 text-slate-700">
          更多操作 <ChevronRight size={16} className="rotate-90" />
        </button>
      </div>
      
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative">
          <Filter className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
          <select className="pl-11 pr-8 py-2.5 bg-white border border-slate-300 rounded-full text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20 appearance-none min-w-[140px]">
            <option>全部任务</option>
            <option>追剧中</option>
            <option>已完结</option>
            <option>失败</option>
          </select>
        </div>
        <div className="relative flex-1 min-w-[240px]">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
          <input 
            type="text" 
            placeholder="搜索资源名称、账号、备注..." 
            className="pl-11 pr-4 py-2.5 bg-white border border-slate-300 rounded-full text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20 w-full"
          />
        </div>
        <button className="p-2.5 bg-white border border-slate-300 rounded-full hover:bg-slate-50 transition-all text-slate-600 shadow-sm">
          <RefreshCw size={20} />
        </button>
      </div>
    </div>

    <div className="flex items-center gap-6 px-2">
      <label className="flex items-center gap-2 cursor-pointer group">
        <div className="w-4 h-4 rounded border border-slate-400 flex items-center justify-center group-hover:border-[#0b57d0] transition-colors">
          <input type="checkbox" className="hidden" />
        </div>
        <span className="text-sm font-medium text-slate-600">全选</span>
      </label>
      <label className="flex items-center gap-2 cursor-pointer group">
        <div className="w-4 h-4 rounded border border-slate-400 flex items-center justify-center group-hover:border-[#0b57d0] transition-colors">
          <input type="checkbox" className="hidden" />
        </div>
        <span className="text-sm font-medium text-slate-600">同步删除网盘</span>
      </label>
    </div>

    <div className="grid grid-cols-1 gap-4">
      {/* Task Card Example */}
      <div className="bg-white rounded-3xl border border-slate-200/60 p-6 shadow-sm hover:shadow-md transition-all group relative overflow-hidden">
        <div className="absolute top-0 left-0 w-1.5 h-full bg-[#0b57d0]" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pl-2">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#d3e3fd] flex items-center justify-center text-[#0b57d0] shrink-0">
              <PlayCircle size={24} />
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h3 className="font-bold text-slate-900 text-lg">北上 (2025)</h3>
                <span className="px-2.5 py-1 bg-[#d3e3fd] text-[#041e49] rounded-md text-xs font-bold uppercase tracking-wider">追剧中</span>
              </div>
              <p className="text-sm text-slate-500 mt-1">账号: 138****8888 • 分组: 日更</p>
              <div className="flex items-center gap-4 mt-3">
                <div className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 px-3 py-1.5 rounded-lg">
                  <Files size={16} className="text-slate-400" />
                  <span>更新目录: /影视/国产剧/北上</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-3">
            <div className="text-right">
              <div className="text-sm font-bold text-slate-900">12 / 24 集</div>
              <div className="w-36 h-2 bg-slate-100 rounded-full mt-2 overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '50%' }}
                  className="h-full bg-[#0b57d0] rounded-full" 
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500 hover:text-[#0b57d0] transition-colors">
                <RefreshCw size={18} />
              </button>
              <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500 hover:text-slate-900 transition-colors">
                <MoreVertical size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Completed Task Example */}
      <div className="bg-white rounded-3xl border border-slate-200/60 p-6 shadow-sm hover:shadow-md transition-all group relative overflow-hidden opacity-80">
        <div className="absolute top-0 left-0 w-1.5 h-full bg-[#146c2e]" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pl-2">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#c4eed0] flex items-center justify-center text-[#146c2e] shrink-0">
              <CheckCircle2 size={24} />
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h3 className="font-bold text-slate-900 text-lg">繁花 (2024)</h3>
                <span className="px-2.5 py-1 bg-[#c4eed0] text-[#0d4f1f] rounded-md text-xs font-bold uppercase tracking-wider">已完结</span>
              </div>
              <p className="text-sm text-slate-500 mt-1">账号: 138****8888 • 分组: 经典</p>
              <div className="flex items-center gap-4 mt-3">
                <div className="flex items-center gap-2 text-sm text-slate-600 bg-slate-50 px-3 py-1.5 rounded-lg">
                  <Files size={16} className="text-slate-400" />
                  <span>更新目录: /影视/国产剧/繁花</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-3">
            <div className="text-right">
              <div className="text-sm font-bold text-slate-900">30 / 30 集</div>
              <div className="w-36 h-2 bg-slate-100 rounded-full mt-2 overflow-hidden">
                <div className="h-full bg-[#146c2e] rounded-full w-full" />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500 hover:text-slate-900 transition-colors">
                <MoreVertical size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const Modal = ({ isOpen, onClose, title, children }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode }) => (
  <AnimatePresence>
    {isOpen && (
      <>
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[200]"
        />
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-2xl bg-[#f8fafd] rounded-[28px] shadow-2xl z-[201] overflow-hidden"
        >
          <div className="px-8 py-6 flex items-center justify-between">
            <h3 className="text-2xl font-normal text-slate-900">{title}</h3>
            <button onClick={onClose} className="p-2 hover:bg-slate-200/50 rounded-full transition-colors text-slate-500">
              <X size={24} />
            </button>
          </div>
          <div className="px-8 pb-6 max-h-[60vh] overflow-y-auto">
            {children}
          </div>
          <div className="px-8 py-6 flex justify-end gap-3">
            <button onClick={onClose} className="px-6 py-2.5 rounded-full text-sm font-medium text-[#0b57d0] hover:bg-[#0b57d0]/10 transition-colors">
              取消
            </button>
            <button className="px-6 py-2.5 rounded-full text-sm font-medium bg-[#0b57d0] text-white hover:bg-[#0b57d0]/90 transition-colors shadow-sm">
              确认提交
            </button>
          </div>
        </motion.div>
      </>
    )}
  </AnimatePresence>
);

const FileManagerTab = () => (
  <div className="space-y-6">
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <select className="bg-white border border-slate-300 rounded-full px-5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20 min-w-[200px]">
          <option>选择账号...</option>
          <option>138****8888 (主账号)</option>
        </select>
        <button className="bg-white border border-slate-300 px-5 py-2.5 rounded-full text-sm font-medium hover:bg-slate-50 transition-all flex items-center gap-2 text-slate-700">
          返回上级
        </button>
        <button className="bg-white border border-slate-300 px-5 py-2.5 rounded-full text-sm font-medium hover:bg-slate-50 transition-all flex items-center gap-2 text-slate-700">
          刷新
        </button>
      </div>
      <div className="flex gap-3">
        <button className="bg-[#0b57d0] text-white px-5 py-2.5 rounded-full text-sm font-medium hover:bg-[#0b57d0]/90 transition-all flex items-center gap-2 shadow-sm">
          <Plus size={18} /> 新建目录
        </button>
        <button className="bg-[#d3e3fd] text-[#041e49] px-5 py-2.5 rounded-full text-sm font-medium hover:bg-[#c2e7ff] transition-all flex items-center gap-2">
          移动选中
        </button>
        <button className="bg-[#f8dada] text-[#900b09] px-5 py-2.5 rounded-full text-sm font-medium hover:bg-[#f8dada]/80 transition-all flex items-center gap-2">
          删除选中
        </button>
      </div>
    </div>

    <div className="bg-white rounded-3xl border border-slate-200/60 p-4 flex items-center justify-between shadow-sm">
      <div className="flex items-center gap-2 text-sm text-slate-500 px-2">
        <Files size={18} />
        <span className="hover:text-[#0b57d0] cursor-pointer font-medium">全部文件</span>
        <ChevronRight size={16} />
        <span className="text-slate-900 font-medium">影视</span>
      </div>
      <div className="flex items-center gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
          <input 
            type="text" 
            placeholder="筛选当前目录..." 
            className="pl-10 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-full text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20 w-56"
          />
        </div>
        <span className="text-sm text-slate-500 font-medium">共 12 项</span>
      </div>
    </div>

    <div className="bg-white rounded-3xl border border-slate-200/60 overflow-hidden shadow-sm">
      <table className="w-full text-left text-sm">
        <thead className="bg-slate-50/50 border-b border-slate-100">
          <tr>
            <th className="px-6 py-4 w-12">
              <input type="checkbox" className="rounded border-slate-400 text-[#0b57d0] focus:ring-[#0b57d0]" />
            </th>
            <th className="px-6 py-4 font-medium text-slate-500">名称</th>
            <th className="px-6 py-4 font-medium text-slate-500">类型</th>
            <th className="px-6 py-4 font-medium text-slate-500">大小</th>
            <th className="px-6 py-4 font-medium text-slate-500">更新时间</th>
            <th className="px-6 py-4 font-medium text-slate-500 text-right">操作</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {[1, 2, 3].map(i => (
            <tr key={i} className="hover:bg-slate-50/50 transition-colors group">
              <td className="px-6 py-4">
                <input type="checkbox" className="rounded border-slate-400 text-[#0b57d0] focus:ring-[#0b57d0]" />
              </td>
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-[#d3e3fd] text-[#0b57d0] rounded-xl">
                    <LayoutGrid size={20} />
                  </div>
                  <span className="font-medium text-slate-900">文件夹 {i}</span>
                </div>
              </td>
              <td className="px-6 py-4 text-slate-500">文件夹</td>
              <td className="px-6 py-4 text-slate-500">-</td>
              <td className="px-6 py-4 text-slate-500">2024-04-05 12:00</td>
              <td className="px-6 py-4 text-right">
                <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500 hover:text-slate-900 transition-colors">
                  <MoreVertical size={18} />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const SettingsTab = () => (
  <div className="max-w-4xl space-y-8">
    <section className="space-y-4">
      <h3 className="text-xl font-medium text-slate-900 flex items-center gap-3">
        <Settings size={24} className="text-[#0b57d0]" /> 系统设置
      </h3>
      <div className="bg-white rounded-3xl border border-slate-200/60 p-8 space-y-8 shadow-sm">
        <div className="space-y-3">
          <label className="text-sm font-medium text-slate-700">系统 API Key</label>
          <div className="flex gap-3">
            <input 
              type="text" 
              placeholder="系统 API Key" 
              className="flex-1 px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20"
            />
            <button className="px-6 py-3 bg-[#d3e3fd] text-[#041e49] rounded-2xl text-sm font-medium hover:bg-[#c2e7ff] transition-colors">
              生成 Key
            </button>
          </div>
          <p className="text-xs text-slate-500">用于第三方调用接口使用。生成后请及时保存设置。</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-3">
            <label className="text-sm font-medium text-slate-700">任务过期天数</label>
            <input 
              type="number" 
              placeholder="默认 3 天" 
              className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20"
            />
          </div>
          <div className="space-y-3">
            <label className="text-sm font-medium text-slate-700">最大重试次数</label>
            <input 
              type="number" 
              placeholder="默认 3 次" 
              className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20"
            />
          </div>
        </div>
      </div>
    </section>

    <section className="space-y-4">
      <h3 className="text-xl font-medium text-slate-900 flex items-center gap-3">
        <Bell size={24} className="text-[#b3261e]" /> 消息推送
      </h3>
      <div className="bg-white rounded-3xl border border-slate-200/60 p-8 space-y-6 shadow-sm">
        <div className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border border-slate-100">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#d3e3fd] text-[#0b57d0] flex items-center justify-center">
              <MessageSquare size={24} />
            </div>
            <div>
              <p className="text-base font-medium text-slate-900">企业微信推送</p>
              <p className="text-sm text-slate-500">通过企业微信机器人推送任务状态</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" className="sr-only peer" />
            <div className="w-14 h-7 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#0b57d0]"></div>
          </label>
        </div>
      </div>
    </section>

    <div className="flex justify-end pt-4">
      <button className="px-8 py-3 bg-[#0b57d0] text-white rounded-full font-medium shadow-sm hover:bg-[#0b57d0]/90 hover:shadow-md transition-all">
        保存所有设置
      </button>
    </div>
  </div>
);

const AutoSeriesTab = () => (
  <div className="space-y-6">
    <div className="flex items-center justify-between">
      <button className="bg-[#0b57d0] text-white px-6 py-2.5 rounded-full text-sm font-medium hover:bg-[#0b57d0]/90 transition-all shadow-sm flex items-center gap-2">
        <Plus size={18} /> 添加追剧
      </button>
      <div className="relative w-72">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
        <input 
          type="text" 
          placeholder="搜索剧集..." 
          className="pl-11 pr-4 py-2.5 bg-white border border-slate-300 rounded-full text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20 w-full"
        />
      </div>
    </div>
    
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {[1, 2].map(i => (
        <div key={i} className="bg-white rounded-3xl border border-slate-200/60 p-6 shadow-sm hover:shadow-md transition-all">
          <div className="flex items-start justify-between mb-4">
            <div className="w-14 h-14 rounded-2xl bg-[#d3e3fd] flex items-center justify-center text-[#0b57d0]">
              <PlayCircle size={28} />
            </div>
            <span className="px-3 py-1 bg-[#d3e3fd] text-[#041e49] rounded-full text-xs font-bold uppercase tracking-wider">更新中</span>
          </div>
          <h3 className="font-bold text-slate-900 text-xl">剧集名称 {i}</h3>
          <p className="text-sm text-slate-500 mt-1">最后更新: 2024-04-05 10:00</p>
          <div className="mt-6 space-y-2">
            <div className="flex justify-between text-sm font-medium">
              <span className="text-slate-600">进度: 8 / 12 集</span>
              <span className="text-[#0b57d0]">66%</span>
            </div>
            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-[#0b57d0] w-[66%]" />
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const OrganizerTab = () => (
  <div className="max-w-4xl space-y-6">
    <div className="bg-white rounded-3xl border border-slate-200/60 p-8 shadow-sm space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-3">
          <label className="text-sm font-medium text-slate-700">源目录</label>
          <div className="flex gap-2">
            <input type="text" placeholder="/整理前" className="flex-1 px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
            <button className="p-3 bg-slate-100 rounded-2xl text-slate-600 hover:bg-slate-200 transition-colors"><Files size={20} /></button>
          </div>
        </div>
        <div className="space-y-3">
          <label className="text-sm font-medium text-slate-700">目标目录</label>
          <div className="flex gap-2">
            <input type="text" placeholder="/整理后" className="flex-1 px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
            <button className="p-3 bg-slate-100 rounded-2xl text-slate-600 hover:bg-slate-200 transition-colors"><Files size={20} /></button>
          </div>
        </div>
      </div>
      
      <div className="space-y-3">
        <label className="text-sm font-medium text-slate-700">整理规则 (正则表达式)</label>
        <textarea rows={4} placeholder="例如: ^(.*) - S(\d+)E(\d+).mp4" className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
      </div>

      <div className="flex items-center justify-between p-5 bg-[#d3e3fd]/50 rounded-2xl border border-[#d3e3fd]">
        <div className="flex items-center gap-3">
          <AlertCircle className="text-[#0b57d0]" size={24} />
          <p className="text-sm text-[#041e49] font-medium">整理器将根据规则自动移动和重命名文件，请谨慎操作。</p>
        </div>
        <button className="px-6 py-2.5 bg-[#0b57d0] text-white rounded-full text-sm font-medium hover:bg-[#0b57d0]/90 transition-all shadow-sm">
          开始整理
        </button>
      </div>
    </div>
  </div>
);

const SubscriptionTab = () => (
  <div className="space-y-6">
    <div className="flex items-center justify-between">
      <button className="bg-[#0b57d0] text-white px-6 py-2.5 rounded-full text-sm font-medium hover:bg-[#0b57d0]/90 transition-all shadow-sm flex items-center gap-2">
        <Plus size={18} /> 添加订阅
      </button>
    </div>
    
    <div className="bg-white rounded-3xl border border-slate-200/60 overflow-hidden shadow-sm">
      <table className="w-full text-left text-sm">
        <thead className="bg-slate-50/50 border-b border-slate-100">
          <tr>
            <th className="px-6 py-4 font-medium text-slate-500">名称</th>
            <th className="px-6 py-4 font-medium text-slate-500">类型</th>
            <th className="px-6 py-4 font-medium text-slate-500">最后检查</th>
            <th className="px-6 py-4 font-medium text-slate-500">状态</th>
            <th className="px-6 py-4 font-medium text-slate-500 text-right">操作</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {[1, 2].map(i => (
            <tr key={i} className="hover:bg-slate-50/50 transition-colors group">
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-[#ffdf99] text-[#7d5700] rounded-xl">
                    <Rss size={20} />
                  </div>
                  <span className="font-medium text-slate-900">订阅源 {i}</span>
                </div>
              </td>
              <td className="px-6 py-4 text-slate-500">RSS 订阅</td>
              <td className="px-6 py-4 text-slate-500">10 分钟前</td>
              <td className="px-6 py-4">
                <span className="px-3 py-1 bg-[#c4eed0] text-[#0d4f1f] rounded-full text-xs font-bold uppercase tracking-wider">正常</span>
              </td>
              <td className="px-6 py-4 text-right">
                <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500 hover:text-slate-900 transition-colors">
                  <MoreVertical size={18} />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const StrmConfigTab = () => (
  <div className="max-w-3xl space-y-8">
    <div className="bg-white rounded-3xl border border-slate-200/60 p-8 shadow-sm space-y-6">
      <div className="space-y-3">
        <label className="text-sm font-medium text-slate-700">WebDAV / HTTP 基础链接</label>
        <input type="text" placeholder="https://example.com/dav" className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
        <p className="text-xs text-slate-500">用于生成 .strm 文件中的播放链接。</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-3">
          <label className="text-sm font-medium text-slate-700">账号映射</label>
          <select className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20">
            <option>138****8888</option>
          </select>
        </div>
        <div className="space-y-3">
          <label className="text-sm font-medium text-slate-700">生成模式</label>
          <select className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20">
            <option>全量生成</option>
            <option>增量更新</option>
          </select>
        </div>
      </div>

      <div className="pt-6">
        <button className="w-full py-4 bg-[#0b57d0] text-white rounded-full font-medium shadow-sm hover:bg-[#0b57d0]/90 transition-all flex items-center justify-center gap-2">
          <Link2 size={20} /> 生成 STRM 文件
        </button>
      </div>
    </div>
  </div>
);

const MediaTab = () => (
  <div className="space-y-6">
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-4">
        <div className="flex bg-slate-200/50 p-1 rounded-xl">
          <button className="p-2 bg-white text-slate-900 rounded-lg shadow-sm"><LayoutGrid size={18} /></button>
          <button className="p-2 text-slate-500 hover:text-slate-700 rounded-lg"><ClipboardList size={18} /></button>
        </div>
      </div>
      <div className="flex gap-2">
        <button className="px-6 py-2.5 bg-[#d3e3fd] text-[#041e49] rounded-full text-sm font-medium hover:bg-[#c2e7ff] transition-all">
          扫描媒体库
        </button>
      </div>
    </div>
    
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
      {[1, 2, 3, 4, 5, 6].map(i => (
        <div key={i} className="group cursor-pointer">
          <div className="aspect-[2/3] bg-slate-200 rounded-2xl overflow-hidden relative mb-3 shadow-sm group-hover:shadow-xl transition-all group-hover:-translate-y-1">
            <img 
              src={`https://picsum.photos/seed/movie${i}/400/600`} 
              alt="Movie Poster" 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
              <button className="w-full py-2.5 bg-white/20 backdrop-blur-md text-white rounded-full text-sm font-medium hover:bg-white/30 transition-colors">
                立即播放
              </button>
            </div>
          </div>
          <h4 className="font-medium text-slate-900 text-sm truncate">电影名称 {i}</h4>
          <p className="text-xs text-slate-500 mt-0.5">2024 • 4K HDR</p>
        </div>
      ))}
    </div>
  </div>
);

const FloatingActions = () => {
  const [isOpen, setIsOpen] = useState(false);
  
  const actions = [
    { icon: Cpu, label: 'CloudSaver', color: 'bg-[#d3e3fd] text-[#0b57d0]' },
    { icon: MessageSquare, label: 'AI Assistant', color: 'bg-[#f3e8ff] text-[#7e22ce]' },
    { icon: Link2, label: 'STRM Generator', color: 'bg-[#c4eed0] text-[#146c2e]' },
    { icon: Bell, label: 'Custom Push', color: 'bg-[#ffdf99] text-[#7d5700]' },
    { icon: FileText, label: 'Logs', color: 'bg-slate-200 text-slate-700' },
  ];

  return (
    <div className="fixed bottom-8 right-8 z-[100] flex flex-col items-end gap-4">
      <AnimatePresence>
        {isOpen && (
          <div className="flex flex-col items-end gap-3 mb-2">
            {actions.map((action, index) => (
              <motion.button
                key={action.label}
                initial={{ opacity: 0, scale: 0.5, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.5, y: 20 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center gap-3 group"
              >
                <span className="px-4 py-2 bg-white rounded-xl text-sm font-medium text-slate-700 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity">
                  {action.label}
                </span>
                <div className={`w-14 h-14 rounded-2xl ${action.color} flex items-center justify-center shadow-sm hover:shadow-md hover:scale-105 transition-all`}>
                  <action.icon size={24} />
                </div>
              </motion.button>
            ))}
          </div>
        )}
      </AnimatePresence>
      
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`w-16 h-16 rounded-2xl ${isOpen ? 'bg-[#d3e3fd] text-[#041e49] rotate-45' : 'bg-[#0b57d0] text-white'} flex items-center justify-center shadow-lg transition-all duration-300 hover:shadow-xl active:scale-95`}
      >
        <Plus size={32} className="transition-transform" />
      </button>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('task');
  const [isAddAccountOpen, setIsAddAccountOpen] = useState(false);
  const [isCreateTaskOpen, setIsCreateTaskOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const tabs: { id: TabType, label: string, icon: any }[] = [
    { id: 'account', label: '账号', icon: User },
    { id: 'fileManager', label: '文件', icon: Files },
    { id: 'task', label: '任务', icon: ClipboardList },
    { id: 'autoSeries', label: '自动追剧', icon: PlayCircle },
    { id: 'organizer', label: '整理器', icon: LayoutGrid },
    { id: 'subscription', label: '订阅', icon: Rss },
    { id: 'strmConfig', label: 'STRM', icon: Link2 },
    { id: 'media', label: '媒体', icon: Monitor },
    { id: 'settings', label: '系统', icon: Settings },
  ];

  const activeTabLabel = tabs.find(t => t.id === activeTab)?.label || '控制台';

  return (
    <div className="flex h-screen bg-[#f8fafd] overflow-hidden font-sans">
      
      {/* Mobile Navigation Drawer Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-slate-900/40 z-40 md:hidden"
            />
            <motion.nav 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', bounce: 0, duration: 0.4 }}
              className="fixed inset-y-0 left-0 w-72 bg-[#f8fafd] flex flex-col z-50 md:hidden shadow-2xl"
            >
              <div className="px-6 py-8">
                <h1 className="text-2xl font-medium text-slate-900">天翼自动转存</h1>
                <p className="text-sm text-slate-500 mt-1">Material Design 3</p>
              </div>
              <div className="flex-1 px-3 space-y-1 overflow-y-auto">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-full text-sm font-medium transition-colors ${
                      activeTab === tab.id 
                        ? 'bg-[#c2e7ff] text-[#001d35]' 
                        : 'text-slate-700 hover:bg-slate-200/50'
                    }`}
                  >
                    <tab.icon size={22} className={activeTab === tab.id ? 'text-[#001d35]' : 'text-slate-500'} />
                    {tab.label}
                  </button>
                ))}
              </div>
            </motion.nav>
          </>
        )}
      </AnimatePresence>

      {/* Desktop Navigation Drawer */}
      <nav className="w-72 bg-[#f8fafd] flex-col hidden md:flex z-10">
        <div className="px-8 py-8">
          <h1 className="text-2xl font-medium text-slate-900">天翼自动转存</h1>
          <p className="text-sm text-slate-500 mt-1">Material Design 3</p>
        </div>
        <div className="flex-1 px-3 space-y-1 overflow-y-auto pb-6">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-4 px-5 py-3.5 rounded-full text-sm font-medium transition-colors ${
                activeTab === tab.id 
                  ? 'bg-[#c2e7ff] text-[#001d35]' 
                  : 'text-slate-700 hover:bg-slate-200/50'
              }`}
            >
              <tab.icon size={22} className={activeTab === tab.id ? 'text-[#001d35]' : 'text-slate-500'} />
              {tab.label}
            </button>
          ))}
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 h-screen relative bg-white rounded-tl-3xl shadow-sm border-l border-t border-slate-200/50">
        
        {/* Top App Bar */}
        <header className="h-16 flex items-center justify-between px-4 md:px-8 bg-white/80 backdrop-blur-md z-10 sticky top-0 rounded-tl-3xl">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsMobileMenuOpen(true)}
              className="p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-700 md:hidden"
            >
              <Menu size={24} />
            </button>
            <h2 className="text-2xl font-normal text-slate-800">{activeTabLabel}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2.5 rounded-full hover:bg-slate-100 transition-colors text-slate-700">
              <Search size={22} />
            </button>
            <button className="p-2.5 rounded-full hover:bg-slate-100 transition-colors text-slate-700">
              <Bell size={22} />
            </button>
            <div className="w-9 h-9 rounded-full bg-[#0b57d0] text-white flex items-center justify-center font-medium text-sm ml-2 cursor-pointer hover:shadow-md transition-shadow">
              U
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-32">
          <div className="max-w-6xl mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2, ease: "easeOut" }}
              >
                {activeTab === 'account' && <AccountTab onAddAccount={() => setIsAddAccountOpen(true)} />}
                {activeTab === 'task' && <TaskTab onCreateTask={() => setIsCreateTaskOpen(true)} />}
                {activeTab === 'fileManager' && <FileManagerTab />}
                {activeTab === 'autoSeries' && <AutoSeriesTab />}
                {activeTab === 'organizer' && <OrganizerTab />}
                {activeTab === 'subscription' && <SubscriptionTab />}
                {activeTab === 'strmConfig' && <StrmConfigTab />}
                {activeTab === 'media' && <MediaTab />}
                {activeTab === 'settings' && <SettingsTab />}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        <FloatingActions />
      </main>

      {/* Modals */}
      <Modal 
        isOpen={isAddAccountOpen} 
        onClose={() => setIsAddAccountOpen(false)} 
        title="添加账号"
      >
        <form className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">用户名</label>
              <input type="text" required className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">密码</label>
              <input type="password" required className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Cookie (可选)</label>
            <textarea rows={3} className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
            <p className="text-xs text-slate-500">密码和 Cookie 至少填写一个，如果都填写，则只有账号密码生效。</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">别名</label>
              <input type="text" className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">账号类型</label>
              <select className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20">
                <option value="personal">个人云</option>
                <option value="family">家庭云</option>
              </select>
            </div>
          </div>
        </form>
      </Modal>

      <Modal 
        isOpen={isCreateTaskOpen} 
        onClose={() => setIsCreateTaskOpen(false)} 
        title="创建任务"
      >
        <form className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">选择账号</label>
            <select className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20">
              <option>138****8888 (主账号)</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">分享链接</label>
            <div className="flex gap-3">
              <input type="text" placeholder="分享链接" className="flex-1 px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
              <input type="text" placeholder="访问码" className="w-28 px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">任务名称</label>
            <input type="text" className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">保存目录</label>
              <div className="flex gap-2">
                <input type="text" readOnly className="flex-1 px-5 py-3 bg-slate-100 border border-slate-200 rounded-2xl text-sm text-slate-500" />
                <button type="button" className="px-4 py-3 bg-slate-100 rounded-2xl text-slate-600 hover:bg-slate-200 transition-colors">
                  <Files size={20} />
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">任务分组</label>
              <input type="text" placeholder="例如：日更 / 电影" className="w-full px-5 py-3 bg-slate-50 border border-slate-300 rounded-2xl text-sm outline-none focus:ring-2 focus:ring-[#0b57d0]/20" />
            </div>
          </div>
        </form>
      </Modal>
    </div>
  );
}
